# Aureum Foundation — Part 1 Starter

## Student Information
- Name: [OFENTSE MOEPI]
- Student Number: [ST10476703]
- Module: Web Development

## Overview
HTML-first skeleton with 5 pages, semantic structure, and shared navigation.

## Structure
- Root: index.html, about.html, services.html, enquiry.html, contact.html
- Folders: /css, /js, /images

## Notes
- Replace placeholders with researched content and licensed images.
- Keep commit messages descriptive.

## Changelog
- v0.1 — Initial scaffold committed.
